/* Test servidor sin desplegar el frontend. npm run test:v2 (requiere npm install). */
const ts = require('typescript');
const fs = require('fs');
const path = require('path');
const Module = require('module');
const assert=require('node:assert/strict');
const root=__dirname;
const originalResolve=Module._resolveFilename;
Module._resolveFilename=function(request,parent,...rest){
 if(request==='server-only'||request==='next/headers')return path.resolve(root,'tests-server-only.cjs');
 if(request.startsWith('@/'))request=path.resolve(root,request.substring(2));
 return originalResolve.call(this,request,parent,...rest);
};
require.extensions['.ts']=function(mod,filename){const source=fs.readFileSync(filename,'utf8');const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020,jsx:ts.JsxEmit.ReactJSX,esModuleInterop:true}}).outputText;mod._compile(js,filename);};
const home=path.join(root,'.demo-state');
if(fs.existsSync(home))fs.renameSync(home,`${home}.pretest-${process.pid}`);
function reset(){if(fs.existsSync(home))fs.rmSync(home,{recursive:true,force:true});const backup=`${home}.pretest-${process.pid}`;if(fs.existsSync(backup))fs.renameSync(backup,home);}
try {
 const a=require('./lib/server/auth.ts'),c=require('./lib/server/clinical.ts');
 const s=a.readState();assert.equal(s.users.filter(u=>u.role==='paciente').length,24);assert.equal(s.users.filter(u=>u.role==='medico').length,2);
 const doc=s.users.find(u=>u.id==='medico-1');const doc2=s.users.find(u=>u.id==='medico-2');const p=s.users.find(u=>u.dni==='90000001');
 assert.ok(!a.hasPermission(s,doc,'90000001'));
 assert.ok(!a.authenticate('medico.demo@sjl.test','wrong').token);
 assert.ok(a.authenticate('medico.demo@sjl.test','DemoMedico2026!','medico','CMP-DEMO-001').token);
 assert.ok(a.authenticate('paciente01@demo.sjl.test','DemoPaciente2026!','paciente','90000001').token);
 assert.ok(!a.authenticate('paciente01@demo.sjl.test','DemoPaciente2026!','paciente','90000002').token);
 const resumen=c.clinicalSummary('90000001');assert.ok(resumen.atenciones.length>=5);assert.ok(resumen.examenes.length>=10);assert.ok(resumen.atenciones.every(x=>x.fechaHora&&x.establecimiento&&x.profesional));
 assert.ok(resumen.examenes.some(x=>x.unidad&&x.referencia));
 assert.ok(!a.hasPermission(a.readState(),doc,'90000001'));
 a.requestAccess(doc,'90000001','Consulta de continuidad clínica de demostración');
 let x=a.userRequests(p)[0];assert.equal(x.estado,'pendiente');
 a.decide(p,x.id,'aprobar',1);assert.ok(a.hasPermission(a.readState(),doc,'90000001'));
 assert.ok(!a.hasPermission(a.readState(),doc2,'90000001'));
 a.registerAccess(doc,p.id,true);assert.ok(a.userEvents(p).some(e=>e.accion==='historia_consultada'));
 a.decide(p,x.id,'revocar');assert.ok(!a.hasPermission(a.readState(),doc,'90000001'));
 const res=c.clinicalSummary('90000001','minsa');assert.ok(res.traza.sistemas.some(x=>x.clave==='minsa'&&x.estado==='no_disponible'));
 assert.equal(a.checkOrigin({headers:{get:()=>"http://evil.example"},url:'http://localhost:3000/api/portal/login'}),false);
 console.log(`OK V2: 2 médicos, 24 pacientes; login, aislamiento, permisos, revocación, auditoría, ${resumen.atenciones.length} atenciones, ${resumen.examenes.length} resultados y caída parcial.`);
} finally {reset();}
